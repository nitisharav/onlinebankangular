import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homepagemain',
  templateUrl: './homepagemain.component.html',
  styleUrls: ['./homepagemain.component.css']
})
export class HomepagemainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
